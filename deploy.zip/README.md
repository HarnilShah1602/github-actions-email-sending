# github-actions-email-sending
automates the process of e-mail sending
